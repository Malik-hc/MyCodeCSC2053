package com.example.recipe;

public class Meal {
    private String mealName;

    private String mealDescription;

    public Meal(String mealName, String mealDescription) {
        this.mealName = mealName;
        this.mealDescription = mealDescription;
    }

    public String getMealName(){

        return mealName;
    }

    public String getMealDescription(){
        return mealDescription;
    }

    public void setMealName(String mealName){
        this.mealName = mealName;
    }
}

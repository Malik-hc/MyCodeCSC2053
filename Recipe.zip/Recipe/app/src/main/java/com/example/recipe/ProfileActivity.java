package com.example.recipe;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);
        TextView nameText = findViewById(R.id.description);

        String mealName = "Meal Name not set";

        Bundle extras= getIntent().getExtras();
        if(extras != null){
            mealName = extras.getString("mealName");
        }

        nameText.setText(mealName);

    }

}

package com.example.recipe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Meal> mealList;
    private RecyclerView recyclerView;
    private recyclerAdapter.RecyclerViewClickListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        mealList = new ArrayList<>();

        setMealInfo();
        setAdapter();
    }


    private void setAdapter() {
        setOnClickListener();
        recyclerAdapter adapter = new recyclerAdapter(mealList, listener);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void setOnClickListener() {
        listener = (v, position) -> {
            Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
            intent.putExtra("mealName", mealList.get(position).getMealName());
            startActivity(intent);
        };
    }

    private void setMealInfo() {
        mealList.add(new Meal("Crispy Rice Spicy Salmon","Crispy Rice Spicy Salmon recipe is the perfect two-bite appetizer or main course. Pan-fried sushi rice cakes topped with smashed avocado and spicy salmon, so easy and so delicious!"));
        mealList.add(new Meal("Honey Jerk Wings","Honey Jerk Chicken Wings are a spicy, complex flavored dish. Baked in the oven to a crisp and served with a dipping sauce on the side."));
        mealList.add(new Meal("Crab and Shrimp Stuffed Salmon","This is literally seafood heaven- jumbo lump crab and shrimp, all stuffed in a delicious filet of salmon. You can’t go wrong!"));
        mealList.add(new Meal("Oxtail Stew","This deeply flavoured oxtail dish starts with the oxtail intensely marinated in a variety of Jamaican spices then braised down in the tastiest savoury sauce."));
        mealList.add(new Meal("Butter Chicken","The chicken is incredibly tender and injected with flavour from a yogurt marinade, and the Butter Chicken sauce is so ridiculously delicious, you’ll want it on tap!"));
        mealList.add(new Meal("Curry Goat","Insanely delicious slow-cooked Jamaican Spiced Curry that is full of flavor and tender to the bone! An absolutely must-make Jamaican food! So easy to make with minimal prep."));
        mealList.add(new Meal("Candied Salmon","Salmon candy is basically heavily smoked strips of salmon, originally smoked so long they were basically salmon jerky. Nowadays it’s usually lacquered with something sweet, such as brown sugar, maple or birch syrup, or even molasses. "));
        mealList.add(new Meal("Cajun Shrimp Alfredo","This Cajun shrimp fettuccine alfredo is packed full of flavor with a little Cajun twist. It’s perfect for busy weeknights and you’ll say goodbye to jarred sauces when you see how easy it is to make your own! Plus the little punch of sausage really brings that Cajun flavor."));
        mealList.add(new Meal("Churro Cheesecake","Churro Cheesecake bars are quick and luscious. These have a flaky crispy base, creamy center and topped with cinnamon and sugar, divine!"));
        mealList.add(new Meal( "Pizza Dip"," Cheese lovers and pizza fans will love this fast and easy dip recipe!! It’s the perfect party food that’s a guaranteed hit! "));
    }
}